/*
 * wait.h
 *
 * Created: 23-3-2017 11:41:14
 *  Author: Stefan
 */
#ifndef WAIT_H_
#define WAIT_H_

// Wait an amount of milliseconds
// @param int: the amount of milliseconds to wait
void wait(int ms);

#endif /* WAIT_H_ */
